Spready is an enhanced version of the fpsGrid demo.

It tries to show off as many possible functionalities of the fpspreadsheet and 
fpspreadsheetgrid code.

Note:
The file colorbox.pas is needed as long as the patch 0026707 is not included in
Lazarus.