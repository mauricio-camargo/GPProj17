This demo represents a useful tool for measuring the speed of writing to and
reading from various spreadsheet file formats. It contains a gui to setup test
conditions and displays test results in a memo.

Please note that the reading test requires the files created during the writing
test. The test files are created in a subfolder "data" of the directory 
containing the exe file.
