This demo demonstrates how to use fpspreadsheet to read and write files with wiki table format in it.

Note that the write example currently writes a format that the read example cannot understand.