This demo demonstrates how to use fpspreadsheet to read and write Excel 2.x xls 
files.

Please run the write demo before the read demo so the required spreadsheet file
is generated.