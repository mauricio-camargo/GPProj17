This folder contains the palette icons of the visual spreadsheet components.

fpspreadsheetctrls.spp is the source file. It contains the various images as
layers. Use the software "PhotoPlus" (www.serif.com) to open and edit; the
free starter edition is sufficient.

The basic icons are taken from the Lazarus images folder. The Excel overlay is
self-drawn according to an old Excel version.