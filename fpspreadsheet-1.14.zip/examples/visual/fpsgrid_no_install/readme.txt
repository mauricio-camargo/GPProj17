This project demonstrates use of the Lazarus grid component supplied with 
fpspreadsheet. It demonstrates only the basics; a more extensive example can 
be found in the spready demo.

The grid is created at run-time, therefore installation of the package 
laz_fpspreadsheet_visual is not required. Just compile and run...